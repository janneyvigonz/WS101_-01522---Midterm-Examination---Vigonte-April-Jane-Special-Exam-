<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Transaction </title>
    <body>
	     

  </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MidtermExam\carRentalSystem\resources\views/transaction.blade.php ENDPATH**/ ?>