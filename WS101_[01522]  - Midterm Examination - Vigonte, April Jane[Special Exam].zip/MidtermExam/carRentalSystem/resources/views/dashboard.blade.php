@extends('layout')

@section('content')

<!DOCTYPE html>
<html lang="en">
  <head>
    <title> Dashboard </title>
    <body>
	     

  </body>
</html>

@stop