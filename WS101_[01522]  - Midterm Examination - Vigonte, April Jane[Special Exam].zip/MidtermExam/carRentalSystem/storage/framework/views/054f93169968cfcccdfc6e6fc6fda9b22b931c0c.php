
<!DOCTYPE html>
<html>
<head>
  <title>Car Rental System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
      </button>
      <a class="navbar-brand" href="#"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">       
        <li><a href="<?php echo e(url('login')); ?>">Login</a></li>
        <li><a href="<?php echo e(url('signup')); ?>">Signup</a></li>
        <li><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
        <li><a href="<?php echo e(url('transaction')); ?>">Transaction</a></li>
      </ul>
    </div>
  </div>
</nav>
</body>
    <img src="/images/car.jpg" alt="New York" width="1600" height="700">
        <div class="carousel-caption">
          <h2 style="color:DodgerBlue;">Welcome to Car Rental</h2>

    
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>


</html>

<?php /**PATH C:\xampp\htdocs\MidtermExam\carRentalSystem\resources\views/layout.blade.php ENDPATH**/ ?>