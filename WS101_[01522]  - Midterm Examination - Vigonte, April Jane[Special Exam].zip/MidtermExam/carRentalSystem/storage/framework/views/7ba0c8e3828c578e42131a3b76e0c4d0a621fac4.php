<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Carbook - Free Bootstrap 4 Template by Colorlib</title>
    
	     

  </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\APRIL\MidtermExam\carRentalSystem\resources\views/index.blade.php ENDPATH**/ ?>