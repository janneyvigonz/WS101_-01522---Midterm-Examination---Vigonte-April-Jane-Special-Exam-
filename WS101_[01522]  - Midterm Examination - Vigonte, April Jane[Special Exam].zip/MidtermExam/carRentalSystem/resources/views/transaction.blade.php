@extends('layout')

@section('content')

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Transaction </title>
    <body>
	     

  </body>
</html>

@stop